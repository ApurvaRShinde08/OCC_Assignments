const express=require("express");
const server=express();
server.use(express.json())
server.use(express.urlencoded({extended:true}));
const port=3000;

server.get('/',(req,res)=>{
    res.sendFile(__dirname+'/index.html');
})
server.get('/index.html',(req,res)=>{
    res.sendFile(__dirname+'/index.html');
})
server.get('/js/app.js',(req,res)=>{
    res.sendFile(__dirname+'/js/app.js');
});

server.get('/css/style.css',(req,res)=>{
    res.sendFile(__dirname+'/css/style.css');
});
server.listen(port,()=>{
    console.log(`http://localhost:${port}/index.html`);
})