const mymodule=(()=>{
    console.log("mymodule loaded");
    function add(i,j){
        return i+j;
    }
    function sub(i,j){
        return i-j;
    }
    return{
        add:(i,j)=>add(i,j),
        sub:(i,j)=>sub(i,j)
    }

});
// module.exports.mymodule=mymodule;
module.exports=mymodule;

