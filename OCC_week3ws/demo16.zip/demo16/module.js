function add(i,j){
    return i+j;
}

function sub(i,j){
    return i-j;
}
module.exports.add=add;
module.exports.sub=sub;