// const add=require('./module');
// const sub=require('./module');
// const mymodule=require('./module');// cost exprss =require('express')//epress.js
// console.log(mymodule.add(10,20));//express.json()
// console.log(mymodule.sub(10,20));//express.urlencoded()

//cost server=express();
const module2=require('./module2');// cost exprss =require('express')
// console.log(module2.add(10,20));
// console.log(module2.sub(10,20));
// const mymod2=module2.mymodule();
const mymod2=module2();
console.log(mymod2.add(10,20));
console.log(mymod2.sub(10,20));