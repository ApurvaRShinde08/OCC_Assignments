const express=require('express');
const server=express();
const port=3000;

server.use(express.json());
server.use(express.urlencoded({extended:false}));


// GET /
server.get('/',(req,resp)=>{
    resp.sendFile(__dirname+'/index.html');
});
// GET /idex.html
//demo15\index.html
server.get('/index.html',(req,resp)=>{
    console.log(__dirname);
    resp.sendFile(__dirname+'/index.html');
});
// GET /js/app.js

server.get('/js/app.js',(req,resp)=>{
    resp.sendFile(__dirname+'/js/app.js');
});
// GET /welcome
server.get('/welcome',(req,resp)=>{
    resp.sendFile(__dirname+'/welcome.html');
});
// POST /welcome
//server.use(express.json())
//server.use(express.urlencoded({exteded:true}))
//request{
//     body:{
//      firstName:"Amit",
//      lastName:""
//     }

// }
server.post('/welcome',(req,resp)=>{
    const firstName=req.body.firstName;
    const lastName=req.body.lastName;
    console.log("First Name"+firstName);
    console.log("Last Name"+lastName);
    let error=false;
    let error_message=[];
    if(firstName==undefined || firstName.length==0){        
        error_message.push("First Name required");
        error=true;
    }
    if(lastName==undefined || lastName.length==0){
        error_message.push("Last Name required");
        error=true;
    }
    if(error&&error_message.length>0){
        resp.status(500).send({message:error_message});
    }else{
        
    console.log("Called POST method on server");
    resp.sendFile(__dirname+'/welcome.html');
    }
});

server.listen(port,()=>{
    console.log("Server started at ");
    console.log(`http://localhost:${port}/index.html`);
})