console.log("Cliet script started");

console.log("Cliet script ended");