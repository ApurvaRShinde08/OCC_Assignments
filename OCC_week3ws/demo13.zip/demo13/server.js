const express=require("express");
const server=express();
const port=3000;

// display the index.html
server.get('/index.html',(req,resp)=>{
    resp.sendFile(__dirname+'/index.html');
})
// <form action="/welcome" method="GET">

server.get('/welcome',(req,resp)=>{
    resp.sendFile(__dirname+'/welcome.html');
});

// http://localhost:3000/js/app.js
server.get('/js/app.js',(req,resp)=>{
    resp.sendFile(__dirname+'/js/app.js');
});



server.listen(port,()=>{
    console.log("Server Started ");
    console.log(`http://localhost:${port}/index.html`);
});