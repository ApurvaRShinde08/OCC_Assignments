console.log("Client Script Started !");
function onSubmit(){
    const firstName=document.getElementById("firstName").value;
    const lastName=document.getElementById("lastName").value;
    const fname_err=document.getElementById("fname_err");
    const lname_err=document.getElementById("lname_err");
    fname_err.innerHTML="";
    lname_err.innerHTML="";
    if(firstName.length==0||firstName==undefined){
        fname_err.innerHTML="First Name required!";
        return false;
    }
    if(lastName.length==0||lastName==undefined){
        lname_err.innerHTML="Last Name required!";
        return false;
    }
    
    return true;

}


















console.log("Client Script Ended !");