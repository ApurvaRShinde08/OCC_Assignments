// 1. Server is listening on port 3000
// 2. If a client is sending request which has below methods
//  GET
//  POST
//  PUT
//  DELETE
//Step 1 : include the express library in your code
const express=require('express');
//Step 2 : called the express() function to create the application
const app=express();
//Step 3 : dedicated port number to start the servie for the application
const port=3000;

//Step 5 : Define what server will give as response depending onthe method called
//Step 5.a: GET for any request
function onRequest(req,resp){
    const msg="Welcome to the Sever side coding "+
              "<a href='index.html'> Home</a>";
    resp.send(msg);    
}
app.get('/',onRequest);
//To Display /index.html file on client side 
//Step 5.b: GET /index.html
app.get('/index.html',function(req,resp){
    const file_path=__dirname+'/index.html';
    console.log("index.html called");
    resp.sendFile(file_path);
});

//Step 4: Application will be acting like a sever which will receive request
//        on port 3000 
app.listen(port,()=>{
console.log(`Server Listening at : http://localhost:${port}`);
});